#include "../include/common_tongbu.h"

void Myexit(const char* str){
	perror(str);
	cout<<"errorno:"<<errno<<endl;
	exit(1);
}

void printerror(const char* str){
	perror(str);
	cout<<"errorno:"<<errno<<endl;
}


/*************************
 * 服务端初始化，不connect
 * client_fd 文件描述符
 * link_port 端口，myport 自己的端口，ipaddr ip地址
 * nonblock_time表示设置非阻塞的时间
 * **********************/
void client_init_nocon(int& client_fd){
    //加载套接字库，创建套接字
	client_fd = socket(AF_INET,SOCK_STREAM, 0);
    if(client_fd == INVALID_SOCKET){
		Myexit("set socket error");
		exit(-1);
	}
	int flag=1;
    int error = setsockopt(client_fd, SOL_SOCKET, SO_REUSEADDR, (char*)&flag, sizeof(int));
	if (error< 0)
	{
		printerror("setsockopt(SO_REUSEADDR) failed");
	}
    else cout<<"client set SO_REUSEADDR success"<<endl;
}

int my_connect(int& client_fd,struct sockaddr_in& mysock){
	client_init_nocon(client_fd);
    if (connect(client_fd, (struct sockaddr *)&mysock, sizeof(mysock)) < 0) {
        perror("connect error");
        return -1;
    }
    unsigned long uflag = 1;
    int ret = ioctlsocket(client_fd, FIONBIO, &uflag);
    
    if(ret==SOCKET_ERROR)
    {
        Myexit("ioctlsocket NOBLOCK fail!");
    }
    cout<<"connect success"<<endl;
    return 1;
}


int file_size(const char* filename)  
{  
    FILE *fp=fopen(filename,"rb");  
    if(!fp){
        return -1;
    } 
    fseek(fp,0L,SEEK_END);  
    int size=ftell(fp);  
    fclose(fp);  
    return size;  
}  


/*******************************************
 * str输入字符串
 * ans答案
 * 返回值为0表示非数字，1表示正确
 * ****************************************/
bool str2int(const char* str,int & ans){
    ans=0;
    int wz=0;
    bool flag=0;//是否负数
    if(str[0]=='-'){
        flag=1;
        wz=1;
    }
    while(str[wz]){
        if(str[wz]<'0' || str[wz]>'9') return 0;//非数字，错误
        ans=ans*10+str[wz]-'0';
        wz++;
    }
    if(flag) ans=-ans;
    return 1;
}

int gettimeofday(struct timeval *tp, void *tzp)
{
    time_t clock;
    struct tm tm;
    SYSTEMTIME wtm;
    GetLocalTime(&wtm);
    tm.tm_year     = wtm.wYear - 1900;
    tm.tm_mon     = wtm.wMonth - 1;
    tm.tm_mday     = wtm.wDay;
    tm.tm_hour     = wtm.wHour;
    tm.tm_min     = wtm.wMinute;
    tm.tm_sec     = wtm.wSecond;
    tm. tm_isdst    = -1;
    clock = mktime(&tm);
    tp->tv_sec = clock;
    tp->tv_usec = wtm.wMilliseconds * 1000;
    return (0);
}


bool IsDirectory(const char *pDir)
{
    char szCurPath[500];
    ZeroMemory(szCurPath, 500);
    sprintf_s(szCurPath, 500, "%s//*", pDir);
    WIN32_FIND_DATAA FindFileData;
    ZeroMemory(&FindFileData, sizeof(WIN32_FIND_DATAA));

    HANDLE hFile = FindFirstFileA(szCurPath, &FindFileData); /**< find first file by given path. */

    if (hFile == INVALID_HANDLE_VALUE)
    {
        FindClose(hFile);
        return FALSE; /** 如果不能找到第一个文件，那么没有目录 */
    }
    else
    {
        FindClose(hFile);
        return TRUE;
    }
}

bool DeleteDirectory(const char * DirName)
{
    //    CFileFind tempFind;        //声明一个CFileFind类变量，以用来搜索
    char szCurPath[MAX_PATH];        //用于定义搜索格式
    _snprintf(szCurPath, MAX_PATH, "%s//*.*", DirName);    //匹配格式为*.*,即该目录下的所有文件
    WIN32_FIND_DATAA FindFileData;
    ZeroMemory(&FindFileData, sizeof(WIN32_FIND_DATAA));
    HANDLE hFile = FindFirstFileA(szCurPath, &FindFileData);
    bool IsFinded = TRUE;
    while (IsFinded)
    {
        IsFinded = FindNextFileA(hFile, &FindFileData);    //递归搜索其他的文件
        if (strcmp(FindFileData.cFileName, ".") && strcmp(FindFileData.cFileName, "..")) //如果不是"." ".."目录
        {
            std::string strFileName = "";
            strFileName = strFileName + DirName + "//" + FindFileData.cFileName;
            std::string strTemp;
            strTemp = strFileName;
            if (IsDirectory(strFileName.c_str())) //如果是目录，则递归地调用
                DeleteDirectory(strTemp.c_str());
            else
                DeleteFileA(strTemp.c_str());
        }
    }
    FindClose(hFile);

    bool bRet = RemoveDirectoryA(DirName);
    if (bRet == 0) //删除目录
        return FALSE;
    return TRUE;
}

bool DeleteFile_(const char * DirName){
    if (IsDirectory(DirName)) //如果是目录，则递归地调用
        return DeleteDirectory(DirName);
    else
        return DeleteFileA(DirName);
}

time_t gettime(const char* filename){
    WIN32_FILE_ATTRIBUTE_DATA    attr;     //文件属性结构体
    GetFileAttributesExA(filename,GetFileExInfoStandard,&attr);        //获取文件属性
	FILETIME createTime = attr.ftCreationTime;                    //获取文件时间
	FILETIME accessTime = attr.ftLastAccessTime;             
	FILETIME modifyTime = attr.ftLastWriteTime;
	SYSTEMTIME time;                                                     //系统时间结构体
	FileTimeToSystemTime(&modifyTime,&time);             //将文件事件转换为系统时间
    
	tm tm_;
	tm_.tm_year  = time.wYear -1900;
	tm_.tm_mon   = time.wMonth -1;
	tm_.tm_mday  = time.wDay;
	tm_.tm_hour  = time.wHour;
	tm_.tm_min   = time.wMinute;
	tm_.tm_sec   = time.wSecond;
	tm_.tm_isdst = 0;
	time_t t_ = mktime(&tm_);

    return t_;
}



void findDirectory(const char * DirName,Socket_RIO* rio)
{
    char szCurPath[MAX_PATH];        //用于定义搜索格式
    _snprintf(szCurPath, MAX_PATH, "%s//*.*", DirName);    //匹配格式为*.*,即该目录下的所有文件
    WIN32_FIND_DATAA FindFileData;
    ZeroMemory(&FindFileData, sizeof(WIN32_FIND_DATAA));
    HANDLE hFile = FindFirstFileA(szCurPath, &FindFileData);
    bool IsFinded = TRUE;
    while (IsFinded)
    {
        IsFinded = FindNextFileA(hFile, &FindFileData);    //递归搜索其他的文件
        if (strcmp(FindFileData.cFileName, ".") && strcmp(FindFileData.cFileName, "..")) //如果不是"." ".."目录
        {
            std::string strFileName = "";
            strFileName = strFileName + DirName + "/" + FindFileData.cFileName;
            std::string strTemp;
            strTemp = strFileName;

            cout<<strTemp<<endl;
            real_addfile(strTemp.c_str(),rio);
            if (IsDirectory(strFileName.c_str())){
                //如果是目录，则递归地调用
                findDirectory(strTemp.c_str(),rio);
            } 
        }
    }
    FindClose(hFile);
}

void findFile(const char * DirName,Socket_RIO* rio){
    cout<<DirName<<endl;
    real_addfile(DirName,rio);
    if (IsDirectory(DirName)) //如果是目录，则递归地调用    
        findDirectory(DirName,rio);
}
