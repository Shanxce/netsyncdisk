#include "../include/common_order.h"


map<int,file_info* > id_file;
map<int,int > id_order;
static int id_cnt=0;

//发送的包
int real_addfile(const char* filename,Socket_RIO* rio){
    REQUEST request;
    int file_size_=file_size(filename);
    if(file_size_==0){
        return 0;
    }
    id_order[id_cnt]=addFile;
    request.addfile.base={sizeof(ADDFILE),id_cnt++,addFile};
    if(IsDirectory(filename)==true){
        memcpy(request.addfile.fileMd5,"NULL",4);
    }
    else{
        memcpy(request.addfile.fileMd5,md5file(filename).c_str(),32);
    }
        
    request.addfile.fileTime=gettime(filename);
    request.addfile.fileSize=file_size_;
    request.addfile.addrLen=strlen(filename);
    memcpy(request.addfile.fileAddr,filename,strlen(filename));
    
    rio->write(&request,sizeof(ADDFILE));
    return file_size_;
}
void real_delfile(const char* filename,Socket_RIO* rio){
    REQUEST request;
    id_order[id_cnt]=delFile;
    request.delfile.base={sizeof(DELFILE),id_cnt++,delFile};
    request.delfile.fileTime=gettime(filename);
    if(IsDirectory(filename)==true){
        memcpy(request.delfile.fileMd5,"NULL",4);
    }
    else{
        memcpy(request.delfile.fileMd5,md5file(filename).c_str(),32);
    }
    request.delfile.addrLen=strlen(filename);
    memcpy(request.delfile.fileAddr,filename,strlen(filename));
    rio->write(&request,sizeof(DELFILE));
}
void real_modifyname(const char* filename,char* newfilename,Socket_RIO* rio){
    REQUEST request;
    id_order[id_cnt]=modifyFileName;
    request.modifyname.base={sizeof(MODIFYNAME),id_cnt++,modifyFileName};
    request.modifyname.fileTime=gettime(filename);
    request.modifyname.addrLen=strlen(filename);
    memcpy(request.modifyname.fileAddr,filename,strlen(filename));
    request.modifyname.newaddrLen=strlen(newfilename);
    memcpy(request.modifyname.newfileAddr,newfilename,strlen(newfilename));
    rio->write(&request,sizeof(MODIFYNAME));
}
void real_sendfile(int id,Socket_RIO* rio){
    file_info* info=id_file[id];
    if(info->recvLen >= info->fileLen){
        delete[] info->file_name;
        delete[] info->file_md5;
        delete[] info;
        id_file.erase(id);
        id_order.erase(id);
        return;
    }
        
    int endPos=min(info->recvLen+SEND_FILE_SIZE,info->fileLen);
    cout<<"require "<<info->file_name<<endl;

    REQUEST request;
    request.sendfile.base={sizeof(SENDFILE),id,sendFile};
    memcpy(request.sendfile.fileMd5,info->file_md5,strlen(info->file_md5));
    request.sendfile.startPos=info->recvLen;
    request.sendfile.endPos=endPos;
    request.sendfile.addrLen=strlen(info->file_name);
    memcpy(request.sendfile.fileAddr,info->file_name,strlen(info->file_name));  
    // cout<<request.sendfile.addrLen<<endl;  
    while(1){
        if(rio->wlen()<sizeof(SENDFILE))
            continue;
        rio->write(&request,sizeof(SENDFILE));
        break;
    }  
}

int real_register(const char* username, const char* passwd,Socket_RIO* rio){
    REQUEST request;
    id_order[id_cnt]=sendRegister;
    request.register_.base={sizeof(REGISTER),id_cnt++,sendRegister};
    request.register_.passwdLen=strlen(passwd);
    request.register_.usenameLen=strlen(username);
    if(request.register_.passwdLen>=20 || request.register_.usenameLen>=20){
        return -1;
    }
    memcpy(request.register_.passwd,passwd,strlen(passwd));
    memcpy(request.register_.username,username,strlen(username));
    rio->write(&request,sizeof(REGISTER));
    return 0;
}
int real_login(const char* username, const char* passwd,Socket_RIO* rio){
    REQUEST request;
    id_order[id_cnt]=sendLogin;
    request.login.base={sizeof(LOGIN),id_cnt++,sendLogin};
    request.login.passwdLen=strlen(passwd);
    request.login.usenameLen=strlen(username);
    if(request.login.passwdLen>=20 || request.login.usenameLen>=20){
        return -1;
    }
    memcpy(request.login.passwd,passwd,strlen(passwd));
    memcpy(request.login.username,username,strlen(username));
    rio->write(&request,sizeof(LOGIN));
    return 0;
}

//接受的包
void delfile(REQUEST& response,int fd_now,Socket_RIO* rio){
    char* filename=new char[256];
    memcpy(filename,response.delfile.fileAddr,response.delfile.addrLen);
    filename[response.delfile.addrLen]=0;
    bool flag=DeleteFile_(filename);

    cout<<"delete "<<filename<<endl;

    REQUEST request;
    request.response_base={sizeof(RESPONSE_BASE),response.base.id,
        responseBase,flag?YES:NO};
    rio->write(&request,sizeof(RESPONSE_BASE));
    delete[] filename;
}
void addfile(REQUEST& response,int fd_now,Socket_RIO* rio){
    // cout<<response.addfile.fileSize<<" "<<response.addfile.addrLen<<endl;

    char* filename=new char[256];
    memcpy(filename,response.addfile.fileAddr,response.addfile.addrLen);
    filename[response.addfile.addrLen]=0;
    FILE *fp = fopen(filename, "wb+");
    fclose(fp);

    REQUEST request;
    request.response_base={sizeof(RESPONSE_BASE),response.base.id,
        responseBase,YES};
    rio->write(&request,sizeof(RESPONSE_BASE));

    id_file[id_cnt]=new file_info;
    id_file[id_cnt]->file_name=filename;
    id_file[id_cnt]->file_md5=new char[32];
    memcpy(id_file[id_cnt]->file_md5,response.addfile.fileMd5,32);
    id_file[id_cnt]->fileLen=response.addfile.fileSize;
    id_file[id_cnt]->recvLen=0;
    id_order[id_cnt]=sendFile;
    real_sendfile(id_cnt,rio);
    id_cnt++;
}
void sendfile(REQUEST& response,int client_fd,Socket_RIO* rio){
    char* filename=new char[256];
    memcpy(filename,response.sendfile.fileAddr,response.sendfile.addrLen);
    filename[response.sendfile.addrLen]=0;
    int file_size_=file_size(filename);
    FILE *fp=fopen(filename,"rb");
    fseek(fp,response.sendfile.startPos,SEEK_SET); 

    REQUEST request;
    request.response_send.base={sizeof(RESPONSE_SEND),response.sendfile.base.id,responseSend};
    request.response_send.status=YES;
    request.response_send.startPos=response.sendfile.startPos;
    request.response_send.endPos=response.sendfile.endPos;
    fread(request.response_send.content,sizeof(char),
        response.sendfile.endPos-response.sendfile.startPos,fp);
    
    while(1){
        if(rio->wlen()<sizeof(RESPONSE_SEND))
            continue;
        rio->write(&request,sizeof(RESPONSE_SEND));
        break;
    }  
    fclose(fp);
    delete[] filename;
}
void modifyfilename(REQUEST& response,int fd_now,Socket_RIO* rio){
    char* filename=new char[256];
    memcpy(filename,response.modifyname.fileAddr,response.modifyname.addrLen);
    filename[response.modifyname.addrLen]=0;
    char* newfilename=new char[256];
    memcpy(newfilename,response.modifyname.newfileAddr,response.modifyname.newaddrLen);
    newfilename[response.modifyname.newaddrLen]=0;
    int flag=rename(filename,newfilename);

    cout<<"modify "<<filename<<" "<<newfilename<<endl;

    REQUEST request;
    request.response_base={sizeof(RESPONSE_BASE),response.base.id,
        responseBase,(!flag)?YES:NO};
    rio->write(&request,sizeof(RESPONSE_BASE));
    delete[] filename;
    delete[] newfilename;
}

//接受的回复
void responsesend(REQUEST& response,int fd_now,Socket_RIO* rio){
    file_info* info=id_file[response.response_send.base.id];
    FILE *fp = fopen(info->file_name, "a");
    fseek(fp,response.response_send.startPos,SEEK_SET);
    fwrite(response.response_send.content,response.response_send.endPos-response.response_send.startPos
        ,1,fp);
    fclose(fp);
    info->recvLen=response.response_send.endPos;
    cout<<"recv success"<<endl;

    real_sendfile(response.response_send.base.id,rio);
}
void responsebase(REQUEST& response,int fd_now){
    int order=id_order[response.response_base.base.id];
    if(order==sendRegister){
        cout<<"Register "<<response.response_base.status<<endl;
    }
}
void responselogin(REQUEST& response,int fd_now){
    cout<<"Login "<<response.response_login.status<<endl;
    cout<<response.response_login.shareAddrLen<<endl;
    response.response_login.shareAddr[response.response_login.shareAddrLen]=0;
    cout<<response.response_login.shareAddr<<endl;
}


void init_synchronous(const char* foldername,Socket_RIO* rio){
    findFile(foldername,rio);
}

